document.getElementById("myBtn").addEventListener("click", function(){
    var x = document.getElementById('wheelsId');
    
    if (x.style.visibility === 'hidden' || x.style.visibility ==="") 
      x.style.visibility = 'visible';
    } ); 

